$targetFolder = "$env:USERPROFILE\Documents"
$global:files = Get-ChildItem -Path $targetFolder -Recurse -File -Include *.txt,*.docx -ErrorAction SilentlyContinue

