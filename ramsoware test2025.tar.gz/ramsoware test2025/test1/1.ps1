$url = "http://localhost/fakec2"
Invoke-RestMethod -Uri $url -Method Post -Body @{id="enes-vm"; status="started"} | Out-Null

