foreach ($file in $global:files) {
    [System.IO.File]::Open($file.FullName, 'OpenOrCreate', 'ReadWrite', 'ReadWrite').Close()
}

